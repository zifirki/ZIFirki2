let persons = document.getElementsByName("person");
alert(persons);
persons.onclick = function(){
	
}