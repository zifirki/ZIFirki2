<!DOCTYPE html>
<html>
<head>
</head>
<body>
<div id="blockLog">
	<div id="textLog"></div>
	<div id="inputs">
		<div id="login"></div>
		<div id="password"></div>
	</div>
	<div id="goReg"></div>
	<div id="unAdmin"></div>
</div>
</body>
</html>