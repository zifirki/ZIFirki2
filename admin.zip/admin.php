﻿<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="admin.css">
<script src="client.js"></script>
</head>
<body>

<!-- Часть селекта:
<div id="selectPart">
	<div id="Lastname"></div> - Фамилия И.О.
	<div id="position"></div>
</div>
-->

<!--
После нажатия на селект:
<div id="FLname"></div>
<div id="departament"></div>
<div id="position"></div>
<div id="gps"></div>
<div id="email"></div>
<div id="phone"></div>
<div id="buttons">
	<div id="buttonTop">
		<div id="redact"></div>
		<div id="delete"></div>
	</div>
	<div id="buttonBot">
		<div id="add"></div>
	</div>
</div>
-->

<!--
Нажали на кнопку "добавить" или на "изменить"
<div id="FLname"></div> input
<div id="departament"></div> input
<div id="position"></div> input
<div id="gps"></div> input
<div id="email"></div> input
<div id="phone"></div> input
<div id="buttons">
	<div id="save"></div>
	<div id="cancel"></div>
</div>
-->
<!--
<div id="FLname"></div>
<div id="departament"></div>
<div id="position"></div>
<div id="gps"></div>
<div id="email"></div>
<div id="phone"></div>
-->
<div id="Blocks">
	<div id="leftBlock">
		<div id="search">
			<input type="text">
			<div id="search_icon">
				<div id="image"><img src="search.png"></div>
			</div>
		</div>
		<div id="data">
			<div id="person" name="person">
				<div id="FLname">Иванов Игорь Андреевич</div>
				<div id="departament">Инженер</div>
				<div id="position">Отдел технических разработок</div>
				<div id="email">for_apb2015@mail.ru</div>
				<div id="phone">+79211597684</div>
				<!--<div id="buttonsInt">
					<div id="edit"><input type="submit" value="Изменить"></div>
					<div id="delete"><input type="submit" value="Удалить"></div>
				</div>-->
			</div>
			<div id="person" name="person">
				<div id="FLname">Иванов Игорь Андреевич</div>
				<div id="departament">Инженер</div>
				<div id="position">Отдел технических разработок</div>
				<div id="email">for_apb2015@mail.ru</div>
				<div id="phone">+79211597684</div>
			</div>
		</div>
		<div id="buttons"><input type="submit" value="Добавить сотрудника"></div>
	</div>
	<div id="rightBlock">
		<div id="map">
			<img src="map.jpg">
		</div>
	</div>
</div>
</body>
</html>